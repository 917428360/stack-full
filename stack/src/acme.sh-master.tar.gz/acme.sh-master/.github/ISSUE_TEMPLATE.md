<!--
请确保已经更新到最新的代码, 然后贴上来 `--debug 2` 的调试输出. 没有调试输出,我帮不了你.
如何调试 https://github.com/Neilpang/acme.sh/wiki/How-to-debug-acme.sh

If it is a bug report:
- make sure you are able to repro it on the latest released version. 
You can install the latest version by: `acme.sh --upgrade`

- Search the existing issues.
- Refer to the [WIKI](https://wiki.acme.sh).
- Debug info [Debug](https://github.com/Neilpang/acme.sh/wiki/How-to-debug-acme.sh).

-->

Steps to reproduce
------------------

Debug log
-----------------

```
acme.sh  --issue .....   --debug 2
```


